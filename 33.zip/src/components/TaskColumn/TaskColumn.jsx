import React from "react";

import S from "./taskColumn.module.css";
import TaskCard from "./../TaskCard/TaskCard";
import DropArea from "../DropArea/DropArea";
import TaskForm from "../TaskForm/TaskForm";

const oldTasks = localStorage.getItem("tasks");

const TaskColumn = ({
  title,
  tasks,
  status,
  handleDelete,
  setActiveCard,
  onDrop,
}) => {
  const [tasks, setTasks] = useState(JSON.parse(oldTasks) || []);
  
  useEffect(() => {
      localStorage.setItem("tasks", JSON.stringify(tasks));
    }, [tasks]);
  return (
    <section
      className={`${S.task_column} ${
        title == "A fazer"
          ? S.toDoContainer
          : title == "Em andamento"
          ? S.progressContainer
          : title == "Concluído"
          ? S.doneContainer
          : ""
      }`}
    >
      <h2 className={S.task_column_heading}>{title}</h2>

      <DropArea onDrop={() => onDrop(status, 0)} />
      {tasks.map(
        (task, index) =>
          task.status === status && (
            <React.Fragment key={index}>
              <TaskCard
                title={task.task}
                date={task.date}
                handleDelete={handleDelete}
                index={index}
                setActiveCard={setActiveCard}
              />
              <DropArea onDrop={() => onDrop(status, index + 1)} />
            </React.Fragment>
          )
      )}
      <TaskForm setTasks={setTasks} />
      <button className={S.addTask}>+ Adicionar uma tarefa</button>
    </section>
  );
};

export default TaskColumn;
