import React, { useState } from "react";

import S from "./taskForm.module.css";

const TaskForm = ({ setTasks }) => {
  const [taskData, setTaskData] = useState({
    task: "",
    date: "",
    status: "todo",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    setTaskData((prev) => {
      return { ...prev, [name]: value };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!taskData.task || !taskData.date) return;

    const date = new Date(taskData.date);
    const formattedDate = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${(date.getFullYear() + 1).toString().padStart(2, '0')}`;

    setTasks((prev) => {
      return [...prev, { ...taskData, date: formattedDate }];
    });

    setTaskData({
      task: "",
      date: "",
      status: "todo",
    });
  };
  return (
    // <header className={S.app_header}>
    //   <form onSubmit={handleSubmit}>
    //     <input
    //       type="text"
    //       name="task"
    //       value={taskData.task}
    //       className={S.task_input}
    //       placeholder="Enter your task"
    //       onChange={handleChange}
    //     />
    //     <input
    //       type="date"
    //       name="date"
    //       value={taskData.date}
    //       className={S.task_input}
    //       placeholder="Enter your task"
    //       onChange={handleChange}
    //     />

    //     <div className={S.task_form_bottom_line}>
    //       <div>
    //         <select
    //           name="status"
    //           value={taskData.status}
    //           className={S.task_status}
    //           onChange={handleChange}
    //         >
    //           <option value="todo">To do</option>
    //           <option value="doing">Doing</option>
    //           <option value="done">Done</option>
    //         </select>
    //         <button type="submit" className={S.task_submit}>
    //           + Add Task
    //         </button>
    //       </div>
    //     </div>
    //   </form>
    // </header>
    <form className={S.task} onSubmit={handleSubmit}>
      <div className={S.row01}>
        <input
          type="text"
          name="task"
          className={S.inputText}
          placeholder="Digite a tarefa"
          value={taskData.task}
          onChange={handleChange}
          required
        />
      </div>
      <div className={S.row02}>
        <input
          type="date"
          name="date"
          className={S.inputDate}
          value={taskData.date}
          onChange={handleChange}
          required
        />
      </div>
      <button type="submit" className={S.task_submit}>
        + Add Task
      </button>
    </form>
    
  );
};

export default TaskForm;
